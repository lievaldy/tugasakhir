<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>WAREHOUSE MANAGEMENT SYSTEM</title>
    <link rel="icon" href="<?php echo asset('images/icon.png'); ?>"/>

    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>" type="text/css">
    <style>
        body {
            background-color: #d2d6de;
        }
    </style>
</head>
<body>
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script src="<?php echo e(asset('js/login.js')); ?>"></script>
    <script>
        $(function () {
          $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            increaseArea: '20%' /* optional */
          });
        });
      </script>
</body>
</html>
