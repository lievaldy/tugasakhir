<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View All Purchase Requisitions',
        'items' => [
            'Dashboard' => route('index'),
            'View All Purchase Requisitions' => route('purchase_requisition.index'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header p-b-20">
                <div class="box-tools pull-right p-t-5">
                    <a href="<?php echo e(route('purchase_requisition.create')); ?>" class="btn btn-primary btn-sm">CREATE</a>
                </div>
            </div> <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered" id="permissions-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="15%">Number</th>
                            <th width="40%">Description</th>
                            <th width="20%">Project Name</th>
                            <th width="10%">Status</th>
                            <th width="10%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $modelPRs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelPR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($modelPR->number); ?></td>
                                <td><?php echo e($modelPR->description); ?></td>
                                <td><?php echo e($modelPR->project->name); ?></td>
                                <?php if($modelPR->status == 1): ?>
                                    <td>OPEN</td>
                                    <td class="textCenter">
                                        <a href="<?php echo e(route('purchase_requisition.edit', ['id'=>$modelPR->id])); ?>" class="btn btn-primary btn-xs">EDIT</a>
                                        <a href="<?php echo e(route('purchase_requisition.show', ['id'=>$modelPR->id])); ?>" class="btn btn-primary btn-xs">VIEW</a>
                                    </td>
                                <?php elseif($modelPR->status == 2): ?>
                                    <td>CANCELED</td>
                                    <td class="textCenter">
                                        <a href="<?php echo e(route('purchase_requisition.show', ['id'=>$modelPR->id])); ?>" class="btn btn-primary btn-xs">VIEW</a>
                                    </td>
                                <?php else: ?>
                                    <td>ORDERED</td>
                                    <td class="textCenter">
                                        <a href="<?php echo e(route('purchase_requisition.show', ['id'=>$modelPR->id])); ?>" class="btn btn-primary btn-xs">VIEW</a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#permissions-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>