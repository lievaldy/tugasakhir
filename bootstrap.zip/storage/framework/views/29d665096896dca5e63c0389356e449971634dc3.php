<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Physical Inventory » Begin Count Stock',
        'items' => [
            'Dashboard' => route('index'),
            'Begin Count Stock' =>"",
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body">
                <table id="stock-table" class="table table-bordered tableFixed" style="border-collapse:collapse; table-layout:fixed;">
                    <thead>
                        <tr>
                            <th class="p-l-5" style="width: 5%">No</th>
                            <th style="width: 15%">Code</th>
                            <th style="width: 20%">Created At</th>
                            <th style="width: 20%">Status</th>
                            <th style="width: 20%">Items</th>
                            <th style="width: 20%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($counter = 1); ?>
                        <?php $__currentLoopData = $snapshots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $snapshot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="p-l-10"><?php echo e($counter++); ?></td>
                                <td class="p-l-10"><?php echo e($snapshot->code); ?></td>
                                <td class="p-l-10"><?php echo e($snapshot->created_at); ?></td>
                                <td class="p-l-10">
                                    <?php if($snapshot->status == 1): ?>
                                        Open
                                    <?php elseif($snapshot->status == 0): ?>
                                        Closed
                                    <?php elseif($snapshot->status == 2): ?>
                                        Counted
                                    <?php endif; ?>
                                </td>
                                <td class="p-l-10"><?php echo e(count($snapshot->snapshotDetails)); ?></td>
                                <td class="p-l-0 textCenter">
                                    <a class="btn btn-primary btn-xs" href="<?php echo e(route('physical_inventory.countStock', ['id' => $snapshot->id])); ?>">
                                        SELECT
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#sloc, #material').multiselect({
            includeSelectAllOption: true,
            buttonWidth: '100%',
            enableFiltering: true,
            filterBehavior: 'text',
            enableCaseInsensitiveFiltering: true,
            maxHeight: 400,
        })

        $('#stock-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>