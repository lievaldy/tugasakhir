<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View Ship',
        'items' => [
            'Dashboard' => route('index'),
            'View all Ships' => route('ship.index'),
            $ship->name => route('ship.show',$ship->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
            <div class="box-title"></div>
            <div class="box-tools pull-right p-t-5">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-ship')): ?>
                    <a href="<?php echo e(route('ship.edit',['id'=>$ship->id])); ?>" class="btn btn-primary btn-sm">EDIT</a>
                <?php endif; ?>

                
            </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered table-hover showTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Attribute</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Code</td>
                            <td><?php echo e($ship->code); ?></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Name</td>
                            <td><?php echo e($ship->name); ?></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Type</td>
                            <td><?php echo e($ship->type); ?></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Description</td>
                            <td><?php echo e($ship->description); ?></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Status</td>
                            <td class="iconTd">
                                <?php if($ship->status == 1): ?>
                                    <i class="fa fa-check no-padding"></i>
                                <?php elseif($ship->status == 0): ?>
                                    <i class="fa fa-times no-padding"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>