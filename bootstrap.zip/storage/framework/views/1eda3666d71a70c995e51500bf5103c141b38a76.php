<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Configuration',
        'subtitle' => 'Appearance',
        'items' => [
            'Home' => route('index'),
            'Config' => '#',
            'Appearance' => route('config.appearance'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
                <div class="box-title">
                    Default Skin
                </div>
            </div>
            <div class="box-body">
                <form action="<?php echo e(route('config.appearance.save')); ?>" method="POST" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="skin" class="col-sm-2 control-label">Choose Skin</label>
                        <div class="col-sm-10">
                            <?php $__currentLoopData = $defaultSkin->skins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="radio">
                                    <label>
                                    <input class="minimal" type="radio" name="default-skin" value="<?php echo e($skin); ?>" <?php echo e($skin == $defaultSkin->default ? 'checked' : ''); ?>>
                                        <?php echo e($skin); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary pull-right">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    //iCheck for checkbox and radio inputs
    $('input[type="radio"].minimal').iCheck({
      radioClass   : 'iradio_minimal-blue'
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>