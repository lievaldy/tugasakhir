<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Create Cost',
        'items' => [
            'Dashboard' => route('index'),
            'Select Project' => route('rab.selectProjectCost'),
            'Create Cost' => ""
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header p-b-0">
                <div class="col-sm-6 p-l-0">
                    <table>
                        <thead>
                            <th colspan="2">Project Information</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Code</td>
                                <td>:</td>
                                <td>&ensp;<b><?php echo e($project->code); ?></b></td>
                            </tr>
                            <tr>
                                <td>Ship</td>
                                <td>:</td>
                                <td>&ensp;<b><?php echo e($project->ship->name); ?></b></td>
                            </tr>
                            <tr>
                                <td>Customer</td>
                                <td>:</td>
                                <td>&ensp;<b><?php echo e($project->customer->name); ?></b></td>
                            </tr>
                            <tr>
                                <td>Start Date</td>
                                <td>:</td>
                                <td>&ensp;<b><?php
                                            $date = DateTime::createFromFormat('Y-m-d', $project->planned_start_date);
                                            $date = $date->format('d-m-Y');
                                            echo $date;
                                        ?>
                                    </b>
                                </td>
                            </tr>
                            <tr>
                                <td>End Date</td>
                                <td>:</td>
                                <td>&ensp;<b><?php
                                            $date = DateTime::createFromFormat('Y-m-d', $project->planned_end_date);
                                            $date = $date->format('d-m-Y');
                                            echo $date;
                                        ?>
                                    </b>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div id="create_cost">
                <div class="box-body p-t-0">
                    <table id="cost-table" class="table table-bordered tableFixed" style="border-collapse:collapse;">
                        <thead>
                            <tr>
                                <th style="width: 5%">No</th>
                                <th style="width: 20%">Type</th>
                                <th style="width: 45%">Description</th>
                                <th style="width: 20%">Cost</th>
                                <th style="width: 10%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(data,index) in costs">
                                <td>{{ index + 1 }}</td>
                                <td v-if="data.type == 0">Other Cost</td>
                                <td v-else>Process Cost</td>
                                <td class="tdEllipsis">{{ data.description }}</td>
                                <td class="tdEllipsis">Rp.{{ data.cost }}</td>
                                <td class="p-l-0 textCenter">
                                    <a class="btn btn-primary btn-xs" @click="openEditModal(data)" data-toggle="modal" href="#edit_cost">
                                        EDIT
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td class="p-l-10">{{newIndex}}</td>
                                <td class="p-l-0 textLeft">
                                    <selectize v-model="newCost.type" :settings="typeSettings">
                                        <option value="0">Other Cost</option>
                                        <option value="1">Process Cost</option>
                                    </selectize>
                                </td>
                                <td class="p-l-0">
                                    <input v-model="newCost.description" class="form-control width100" rows="2" name="description" placeholder="Description">
                                </td>
                                <td class="p-l-0">
                                    <input v-model="newCost.cost" class="form-control width100" rows="2" name="cost" placeholder="Cost">
                                </td>
                                <td class="p-l-0 textCenter">
                                    <button @click.prevent="add" :disabled="createOk" class="btn btn-primary btn-xs" id="btnSubmit">SUBMIT</button>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                    <div class="modal fade" id="edit_cost">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <h4 class="modal-title">Edit Costs</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="form-group col-sm-12">
                                            <label for="type" class="control-label">Type</label>
                                            <selectize id="type" v-model="editCost.type" :settings="typeSettings">
                                                <option value="0">Other Cost</option>
                                                <option value="1">Process Cost</option>
                                            </selectize>
                                        </div>
                                        <div class="form-group col-sm-12">
                                            <label for="description" class="control-label">Description</label>
                                            <textarea id="description" v-model="editCost.description" class="form-control" rows="2" placeholder="Insert Description here..."></textarea>
                                        </div>
                                        <div class="form-group col-sm-12">
                                            <label for="cost" class="control-label">Cost</label>
                                            <input type="text" id="cost" v-model="editCost.cost" class="form-control" placeholder="Insert Cost here...">
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" :disabled="updateOk" data-dismiss="modal" @click.prevent="update">SAVE</button>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                </div>
            </div>
            
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
            <div id="myPopoverContent" style="display : none;">
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
$(document).ready(function(){
    $('div.overlay').hide();
});

var data = {
    costs : "",
    works : [],
    newIndex : "", 
    newCost : {
        type : "",
        description : "",
        cost : "",
        work_id : "",
        project_id : <?php echo json_encode($project->id, 15, 512) ?>,
    },
    editCost : {
        cost_id : "",
        type : "",
        description : "",
        cost : "",
        work_id : "",
        project_id : <?php echo json_encode($project->id, 15, 512) ?>,
    },
    typeSettings: {
        placeholder: 'Type',
        plugins: ['dropdown_direction'],
        dropdownDirection : 'down',
    },
    workSettings: {
        placeholder: 'Work (Optional)',
        plugins: ['dropdown_direction'],
        dropdownDirection : 'down',
    },
};

var vm = new Vue({
    el: '#create_cost',
    data: data,
    computed:{
        createOk: function(){
            let isOk = false;
                if(this.newCost.name == ""
                || this.newCost.description == ""
                || this.newCost.cost == "")
                {
                    isOk = true;
                }
            return isOk;
        },
        updateOk: function(){
            let isOk = false;
                if(this.editCost.name == ""
                || this.editCost.description == ""
                || this.editCost.cost == "")
                {
                    isOk = true;
                }
            return isOk;
        },

    }, 
    methods:{
        openEditModal(data){
            this.editCost.cost_id = data.id;
            this.editCost.type = data.type;
            this.editCost.description = data.description;
            this.editCost.work_id = data.work_id;
            this.editCost.cost = data.cost;
        },
        getWorks(){
            window.axios.get('/project/getAllWorks/'+this.newCost.project_id).then(({ data }) => {
                this.works = data;
            });
        },
        getCosts(){
            window.axios.get('/rab/getCosts/'+this.newCost.project_id).then(({ data }) => {
                this.costs = data;
                this.newIndex = Object.keys(this.costs).length+1;
                var dT = $('#cost-table').DataTable();
                dT.destroy();
                this.$nextTick(function() {
                    $('#cost-table').DataTable({
                        'paging'      : true,
                        'lengthChange': false,
                        'searching'   : false,
                        'ordering'    : false,
                        'info'        : true,
                        'autoWidth'   : false,
                        'initComplete': function(){
                            $('div.overlay').remove();
                        },
                        columnDefs : [
                            { targets: 0, sortable: false},
                        ]
                    });
                })
            });
        },
        add(){            
            var newCost = this.newCost;
            newCost.cost = newCost.cost.replace(/,/g , '');
            newCost = JSON.stringify(newCost);
            var url = "<?php echo e(route('rab.storeCost')); ?>";
            window.axios.post(url,newCost)
            .then((response) => {
                if(response.data.error != undefined){
                    iziToast.warning({
                        displayMode: 'replace',
                        title: response.data.error,
                        position: 'topRight',
                    });
                }else{
                    iziToast.success({
                        displayMode: 'replace',
                        title: response.data.response,
                        position: 'topRight',
                    });
                }
                
                this.getCosts();
                this.newCost.type = "";
                this.newCost.description = "";
                this.newCost.cost = "";
                this.newCost.work_id = "";                
            })
            .catch((error) => {
                console.log(error);
            })

        },
        update(){            
            var editCost = this.editCost;   
            editCost.cost = editCost.cost.replace(/,/g , '');        
            var url = "/rab/updateCost/"+editCost.cost_id;
            editCost = JSON.stringify(editCost);
            window.axios.patch(url,editCost)
            .then((response) => {
                if(response.data.error != undefined){
                    iziToast.warning({
                        displayMode: 'replace',
                        title: response.data.error,
                        position: 'topRight',
                    });
                }else{
                    iziToast.success({
                        displayMode: 'replace',
                        title: response.data.response,
                        position: 'topRight',
                    });
                }
                
                this.getCosts();
                this.newCost.type = "";
                this.newCost.description = "";
                this.newCost.cost = "";
                this.newCost.work_id = "";
            })
            .catch((error) => {
                console.log(error);
            })


        }
    },
    watch : {
        'newCost.cost': function(newValue) {
            var string_newValue = newValue+"";
            cost_string = string_newValue.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            Vue.nextTick(() => this.newCost.cost = cost_string);
        },

        costs: function(newValue) {
            newValue.forEach(cost => {
                cost.cost = (cost.cost+"").replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");            
            });
        },
        'editCost.cost': function(newValue) {
            var string_newValue = newValue+"";
            cost_string = string_newValue.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            Vue.nextTick(() => this.editCost.cost = cost_string);
        },
    },
    created: function() {
        this.getCosts();
        this.getWorks();
    },
    
});


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>