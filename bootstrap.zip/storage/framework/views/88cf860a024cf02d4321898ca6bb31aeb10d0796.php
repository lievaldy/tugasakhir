<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>ERP - PATRIA</title>
    <link rel="icon" href="<?php echo asset('images/icon.png'); ?>"/>

    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>" type="text/css">
    <style>
        body {
            background-image: url("<?php echo e(asset('/images/login-background.jpeg')); ?>");
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment :fixed;
            background-position :center;
        }
    </style>
</head>
<body>
    <div id="app">
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script src="<?php echo e(asset('js/login.js')); ?>"></script>
</body>
</html>
