<?php $__env->startSection('content-header'); ?>

<?php if($storage_location->id): ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Update Storage Locations',
        'items' => [
            'Dashboard' => route('index'),
            'View All Storage Locations' => route('storage_location.index'),
            $storage_location->name => route('storage_location.show',$storage_location->id),
            'Update' => route('storage_location.edit',$storage_location->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php else: ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Create New Storage Locations',
        'items' => [
            'Dashboard' => route('index'),
            'View All Storage Locations' => route('storage_location.index'),
            'Create New Storage Locations' => route('storage_location.create'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body">
                

                <?php if($storage_location->id): ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('storage_location.update',['id'=>$storage_location->id])); ?>">
                    <input type="hidden" name="_method" value="PATCH">
                <?php else: ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('storage_location.store')); ?>">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="box-body">

                        <div class="form-group">
                            <label for="code" class="col-sm-2 control-label">Code</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="code" name="code" required autofocus value="<?php echo e($storage_location->code == null ? $storage_location_code: $storage_location->code); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Name</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="name" required autofocus value="<?php echo e($storage_location->name); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="type" class="col-sm-2 control-label">Area (m<sup>2</sup>)</label>
            
                            <div class="col-sm-10">
                                <input type='text' onkeypress='validate(event)' class="form-control" id="area" name="area" required value="<?php echo e($storage_location->area); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="description" class="col-sm-2 control-label">Description</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="description" name="description" value="<?php echo e($storage_location->description); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                                <label for="company" class="col-sm-2 control-label">Warehouse</label>
                
                                <div class="col-sm-10">
                                    <select class="form-control" name="warehouse" id="warehouse" required>
                                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                        <div class="form-group">
                            <label for="status" class="col-sm-2 control-label">Status</label>
            
                            <div class="col-sm-10">
                                <select class="form-control" name="status" id="status" required>
                                    <option value="1">Active</option>
                                    <option value="0">Not Active</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <?php if($storage_location->id): ?>
                            <button type="submit" class="btn btn-primary pull-right">SAVE</button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-primary pull-right">CREATE</button>
                        <?php endif; ?>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#status').val("<?php echo e($storage_location->status); ?>");
        if($('#status').val()==null){
            $('#status').val(1);
        }
        
        $('#status').select({
            minimumResultsForSearch: -1
        });
        $('div.overlay').remove();
        $('.alert').addClass('animated bounce');
    });
    document.getElementById("code").readOnly = true;

    function validate(evt) {
    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
        key = event.clipboardData.getData('text/plain');
    } else {
    // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
    }
    var regex = /[0-9]|\./;
    if( !regex.test(key) ) {
        theEvent.returnValue = false;
        if(theEvent.preventDefault) theEvent.preventDefault();
    }
    }
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>