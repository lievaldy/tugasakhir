<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Vendor',
        'items' => [
            'Dashboard' => route('index'),
            'View All Vendors' => route('vendor.index'),
            $vendor->name => route('vendor.show',$vendor->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
                <div class="box-title"></div>
                <div class="box-tools pull-right p-t-5">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-vendor')): ?>
                        <a href="<?php echo e(route('vendor.edit',['id'=>$vendor->id])); ?>" class="btn btn-primary btn-sm">EDIT</a>
                    <?php endif; ?>

                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy-vendor')): ?>
                        <button class="btn btn-danger btn-sm" onclick="event.preventDefault();document.getElementById('delete-form-<?php echo e($vendor->id); ?>').submit();">DELETE</button>
                    <?php endif; ?>

                    <form id="delete-form-<?php echo e($vendor->id); ?>" action="<?php echo e(route('vendor.destroy', ['id' => $vendor->id])); ?>" method="POST" style="display: none;">
                        <input type="hidden" name="_method" value="DELETE">
                        <?php echo csrf_field(); ?>
                    </form> -->
                </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered width100 showTable tableFixed">
                    <thead>
                        <tr>
                            <th style="width: 5%">#</th>
                            <th style="width: 20%">Attribute</th>
                            <th style="width: 65%">Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Code</td>
                            <td><?php echo e($vendor->code); ?></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Name</td>
                            <td><?php echo e($vendor->name); ?></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Address</td>
                            <td class="wordWrap"><?php echo e($vendor->address); ?></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Phone Number</td>
                            <td><?php echo e($vendor->phone_number); ?></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Email</td>
                            <td><?php echo e($vendor->email); ?></td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>Status</td>
                            <td class="iconTd">
                                <?php if($vendor->status == 1): ?>
                                    <i class="fa fa-check"></i>
                                <?php elseif($vendor->status == 0): ?>
                                    <i class="fa fa-times"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>