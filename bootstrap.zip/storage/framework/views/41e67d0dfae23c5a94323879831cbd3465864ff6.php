<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Physical Inventory Adjusted » '.$snapshot->code,
        'items' => [
            'Dashboard' => route('index'),
            'Show Snapshot' => "",
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-blue">
            <div class="row">
                <div class="col-sm-4 col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-blue">
                            <i class="fa fa-envelope"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">PI Document Number</span>
                            <span class="info-box-number"><?php echo e($snapshot->code); ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8 col-md-8 m-t-10">
                    <div class="row">
                        <div class="col-md-2">
                            Status
                        </div>
                        <div class="col-md-3">
                            : 
                            <b> 
                                <?php if($snapshot->status == 1): ?>
                                    Open
                                <?php elseif($snapshot->status == 0): ?>
                                    Closed
                                <?php elseif($snapshot->status == 2): ?>
                                    Counted
                                <?php endif; ?>
                            </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">
                            Created At
                        </div>
                        <div class="col-md-3">
                            : 
                            <b><?php echo e($snapshot->created_at); ?></b>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-body p-t-0">
                <table class="table table-bordered showTable" id="stock-table">
                    <thead>
                        <tr>
                            <th style="width: 5%">No</th>
                            <th style="width: 35%">Material Name</th>
                            <th style="width: 30%">Storage Location</th>
                            <th style="width: 10%">Quantity</th>
                            <th style="width: 10%">Count</th>
                            <th style="width: 10%">Adjusted Stock</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($counter = 1); ?>
                        <?php $__currentLoopData = $snapshot->snapshotDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="p-l-10"><?php echo e($counter++); ?></td>
                                <td class="p-l-10"><?php echo e($details->material->name); ?></td>
                                <td class="p-l-10"><?php echo e($details->storageLocation->name); ?></td>
                                <td class="p-l-10"><?php echo e($details->quantity); ?></td>
                                <td class="p-l-10"><?php echo e($details->count); ?></td>
                                <td class="p-l-10"><?php echo e($details->adjusted_stock); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <?php if($confirm): ?>
                <div class="box-footer">
                    <form id="snapshot" method="POST" action="<?php echo e(route('physical_inventory.storeAdjustStock', ['id' => $snapshot->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="PATCH">
                        <button id="btnSubmit" class="btn btn-primary col-sm-12">APPROVE STOCK ADJUSTMENT</button>
                    </form>
                </div>
            <?php endif; ?>
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#stock-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>