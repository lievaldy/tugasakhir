<?php $__env->startSection('content-header'); ?>

<?php if($branch->id): ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Edit Branch',
        'subtitle' => 'Edit',
        'items' => [
            'Dashboard' => route('index'),
            'View All Branches' => route('branch.index'),
            $branch->name => route('branch.show',$branch->id),
            'Edit Branch' => route('branch.edit',$branch->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php else: ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Create Branch',
        'items' => [
            'Dashboard' => route('index'),
            'View All Branches' => route('branch.index'),
            'Create Branch' => route('branch.create'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body">
                <!-- <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?> -->

                <?php if($branch->id): ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('branch.update',['id'=>$branch->id])); ?>">
                    <input type="hidden" name="_method" value="PATCH">
                <?php else: ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('branch.store')); ?>">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="box-body">

                        <div class="form-group">
                            <label for="code" class="col-sm-2 control-label">Code</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="code" name="code" required autofocus value="<?php echo e($branch->code == null ? $branch_code: $branch->code); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Name</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="name" required autofocus value="<?php echo e($branch->name); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="address" class="col-sm-2 control-label">Address</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="address" name="address" required value="<?php echo e($branch->address); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="phone_number" class="col-sm-2 control-label">Phone Number</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" onkeypress="validate(event)" minlength="10" maxlength="11" id="phone_number" name="phone_number" required value="<?php echo e($branch->phone_number); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="fax" class="col-sm-2 control-label">Fax</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" onkeypress="validate(event)" minlength="10" maxlength="11" id="fax" name="fax" value="<?php echo e($branch->fax); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-sm-2 control-label">Email</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="email" name="email" required value="<?php echo e($branch->email); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="company" class="col-sm-2 control-label">Company</label>
            
                            <div class="col-sm-10">
                                <select class="form-control" name="company" id="company" required>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="status" class="col-sm-2 control-label">Status</label>
            
                            <div class="col-sm-10">
                                <select class="form-control" name="status" id="status" required>
                                    <option value="1">Active</option>
                                    <option value="0">Non Active</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <?php if($branch->id): ?>
                            <button type="submit" class="btn btn-primary pull-right">Save</button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-primary pull-right">Create</button>
                        <?php endif; ?>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#status').val("<?php echo e($branch->status); ?>");
        if($('#status').val()==null){
            $('#status').val(1);
        }
        $('#status').select({
            minimumResultsForSearch: -1
        });
        $('div.overlay').remove();
        $('.alert').addClass('animated bounce');
    

    
        $('#company').val("<?php echo e($branch->company_id); ?>");
        if($('#company').val()==null){
            $('#company').val(1);
        }
        $('#company').select({
            minimumResultsForSearch: -1
        });
        $('div.overlay').remove();
        $('.alert').addClass('animated bounce');

        $("#phone_number").inputmask();
        $("#fax").inputmask();

    });
    
    document.getElementById("code").readOnly = true;

function validate(evt) {
  var theEvent = evt || window.event;

  // Handle paste
  if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
  } else {
  // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
  }
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
    
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>