<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View Purchase Order » '.$modelPO->project->name,
        'items' => [
            'Dashboard' => route('index'),
            'View Purchase Order' => route('purchase_order.show',$modelPO->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-blue">
            <div class="row">
                <div class="col-sm-3 col-md-3">
                    <div class="info-box">
                        <span class="info-box-icon bg-blue">
                            <i class="fa fa-envelope"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">PO Number</span>
                            <span class="info-box-number"><?php echo e($modelPO->number); ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4 m-t-10">
                    <div class="row">
                        <div class="col-md-4">
                            Project Code
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e($modelPO->project->code); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Project Name
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e($modelPO->project->name); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Ship Name
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e($modelPO->project->ship->name); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Ship Type
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e($modelPO->project->ship->type); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Ref Number
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e($modelPO->purchaseRequisition->number); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Total Price
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e(number_format($modelPO->total_price)); ?> </b>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4 m-t-10">
                    <div class="row">
                        <div class="col-md-5">
                            Customer Name
                        </div>
                        <div class="col-md-7 tdEllipsis" data-container="body" data-toggle="tooltip" title="<?php echo e($modelPO->project->customer->name); ?>">
                            : <b> <?php echo e($modelPO->project->customer->name); ?> </b>
                        </div>
                        <div class="col-md-5">
                            Vendor Name
                        </div>
                        <div class="col-md-7">
                            : <b> <?php echo e($modelPO->vendor->code); ?> - <?php echo e($modelPO->vendor->name); ?> </b>
                        </div>
                        <div class="col-md-5">
                            Status
                        </div>
                        <?php if($modelPO->status == 1): ?>
                            <div class="col-md-7">
                                : <b>OPEN</b>
                            </div>
                        <?php elseif($modelPO->status == 2): ?>
                            <div class="col-md-7">
                                : <b>CANCELED</b>
                            </div>
                        <?php else: ?>
                            <div class="col-md-7">
                                : <b>ORDERED</b>
                            </div>
                        <?php endif; ?>
                        <div class="col-md-5">
                            Created By
                        </div>
                        <div class="col-md-7">
                            : <b> <?php echo e($modelPO->user->name); ?> </b>
                        </div>
                        <div class="col-md-5">
                            Created At
                        </div>
                        <div class="col-md-7">
                            : <b> <?php echo e($modelPO->created_at); ?> </b>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered showTable" id="boms-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="35%">Material Name</th>
                            <th width="20%">Quantity</th>
                            <th width="20%">Price / pcs</th>
                            <th width="20%">Sub Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $modelPO->purchaseOrderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $POD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($POD->quantity > 0): ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($POD->material->code); ?> - <?php echo e($POD->material->name); ?></td>
                                    <td><?php echo e(number_format($POD->quantity)); ?></td>
                                    <td><?php echo e(number_format($POD->total_price / $POD->quantity)); ?></td>
                                    <td><?php echo e(number_format($POD->total_price)); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('div.overlay').remove();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>