<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View All Customers',
        'items' => [
            'Dashboard' => route('index'),
            'View All Customers' => route('customer.index'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header m-b-10">
                <div class="box-tools pull-right p-t-5">
                    <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-primary btn-sm">CREATE</a>
                </div>
            </div> <!-- /.box-header -->
            <div class="box-body">
                
                <table class="table table-bordered table-hover tableFixed " id="customer-table">
                    <thead>
                        <tr>
                            <th style="width: 5%">No</th>
                            <th style="width: 10%">Code</th>
                            <th style="width: 35%">Name</th>
                            <th style="width: 35%">Address</th>
                            <th style="width: 10%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($counter = 1); ?>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($counter++); ?></td>
                                <td class="tdEllipsis"><?php echo e($customer->code); ?></td>
                                <td class="tdEllipsis" data-container="body" data-toggle="tooltip" title="<?php echo e($customer->name); ?>"><?php echo e($customer->name); ?></td>
                                <td class="tdEllipsis" data-container="body" data-toggle="tooltip" title="<?php echo e($customer->address); ?>"><?php echo e($customer->address); ?></td>
                                <td class="p-l-0 p-r-0" align="center">
                                    <a href="<?php echo e(route('customer.show', ['id'=>$customer->id])); ?>" class="btn btn-primary btn-xs">VIEW</a>
                                    <a href="<?php echo e(route('customer.edit', ['id'=>$customer->id])); ?>" class="btn btn-primary btn-xs">EDIT</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#customer-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>