<?php $__env->startSection('content-header'); ?>
    <?php if($menu == "view_rab"): ?>
        <?php $__env->startComponent('components.breadcrumb', [
                'title' => 'View RAP » Select Project',
                'items' => [
                    'Dashboard' => route('index'),
                    'Select Project' => route('rab.indexSelectProject'),
                ]
            ]); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php elseif($menu == "create_cost"): ?>
        <?php $__env->startComponent('components.breadcrumb', [
                'title' => 'Create Cost » Select Project',
                'items' => [
                    'Dashboard' => route('index'),
                    'Select Project' => route('rab.selectProjectCost'),
                ]
            ]); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php elseif($menu == "assign_cost"): ?>
        <?php $__env->startComponent('components.breadcrumb', [
                'title' => 'Assign Cost » Select Project',
                'items' => [
                    'Dashboard' => route('index'),
                    'Select Project' => route('rab.selectProjectAssignCost'),
                ]
            ]); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php elseif($menu == "view_planned_cost"): ?>
        <?php $__env->startComponent('components.breadcrumb', [
                'title' => 'View Planned Cost » Select Project',
                'items' => [
                    'Dashboard' => route('index'),
                    'Select Project' => route('rab.selectProjectViewCost'),
                ]
            ]); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php elseif($menu == "view_rm"): ?>
        <?php $__env->startComponent('components.breadcrumb', [
                'title' => 'View Remaining Material » Select Project',
                'items' => [
                    'Dashboard' => route('index'),
                    'Select Project' => route('rab.selectProjectViewRM'),
                ]
            ]); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">List of Projects</h3>
            </div> <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered" id="boms-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="25%">Project Name</th>
                            <th width="40%">Customer</th>
                            <th width="25%">Ship</th>
                            <th width="5%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($project->name); ?></td>
                                <td><?php echo e($project->customer->name); ?></td>
                                <td><?php echo e($project->ship->name); ?></td>
                                <?php if($menu == "create_rab"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('rab.create', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php elseif($menu == "view_rab"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('rab.index', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php elseif($menu == "create_cost"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('rab.createCost', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php elseif($menu == "assign_cost"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('rab.assignCost', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php elseif($menu == "view_planned_cost"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('rab.viewPlannedCost', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php elseif($menu == "view_rm"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('rab.selectWBS', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#boms-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>