<h1><?php echo e($title); ?></h1>
<ol class="breadcrumb">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->last): ?>
            <li class="active"><?php echo e($name); ?></li>
        <?php else: ?>
            <li><a href="<?php echo e($url); ?>"><?php echo e($name); ?></a></li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>