<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Assign Bill Of Material',
        'subtitle' => '',
        'items' => [
            'Dashboard' => route('index'),
            'Select Project' => route('bom.selectProject'),
            'Assign Bill Of Material' => route('bom.indexProject'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <table>
                    <thead>
                        <th colspan="2"></th>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="p-r-40">Project Code</td>
                            <td class="p-r-5">:</td>
                            <td><b><?php echo e($project->code); ?></b></td>
                        </tr>
                        <tr>
                            <td>Project Name</td>
                            <td>:</td>
                            <td><b><?php echo e($project->name); ?></b></td>
                        </tr>
                        <tr>
                            <td>Ship Name</td>
                            <td>:</td>
                            <td><b><?php echo e($project->ship->name); ?></b></td>
                        </tr>
                        <tr>
                            <td>Ship Type</td>
                            <td>:</td>
                            <td><b><?php echo e($project->ship->type); ?></b></td>
                        </tr>
                        <tr>
                            <td>Customer</td>
                            <td>:</td>
                            <td><b><?php echo e($project->customer->name); ?></b></td>
                        </tr>
                    </tbody>
                </table>
            </div> <!-- /.box-header -->
            
            <div class="box-body p-t-0" id="assign-bom">
                <table class="table table-bordered" id="boms-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="15%">Code</th>
                            <th width="30%">BOM Description</th>
                            <th width="15%">Status</th>
                            <th width="25%">Work</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(bom,index) in modelBom ">
                            <td>{{ index + 1 }}</td>
                            <td>{{ bom.code }}</td>
                            <td>{{ bom.description}}</td>
                            <template v-if="bom.work_id == null">
                                <td>{{ "Not Assigned" }}</td>
                                
                            </template>
                            <template v-else>
                                <td>{{ "Assigned" }}</td>
                                
                            </template>
                            <td class="no-padding">
                                <selectize v-model="bom.work_id" :id="index" :settings="workSettings">
                                    <option v-for="(work, index) in works" :value="work.id" >{{ work.name }}
                                    </option>
                                </selectize>   
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#boms-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : true,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').hide();
            }
        });
    });

    function getNewBom(project_id){
        window.axios.get('/api/getNewBom/'+project_id).then(({ data }) => {
            this.data.modelBom = data;
            
        });
    }

    function save(work_id,index){
        var modelBom = this.data.modelBom;
        var bom_id = modelBom[index].id;
        var data = {
            bom_id : bom_id,
            work_id : work_id
        }
        $('div.overlay').show();
        data = JSON.stringify(data);
        var url = "<?php echo e(route('bom.storeAssignBom')); ?>";
        
        window.axios.patch(url,data).then((response) => {
            getNewBom(response.data.project_id);

            iziToast.success({
                title: 'Success Assign BOM !',
                position: 'topRight',
                displayMode: 'replace'
            });
        })
        .catch((error) => {
            iziToast.warning({
                title: 'Please Try Again..',
                position: 'topRight',
                displayMode: 'replace'
            });
            console.log(error);
            $('div.overlay').hide();
        })
        $('div.overlay').hide();
    }

    var data = {
        modelBom : <?php echo json_encode($modelBOM, 15, 512) ?>,
        works : <?php echo json_encode($works, 15, 512) ?>,
        workSettings: {
            placeholder: 'Please Select Work',
            onChange : function(id){
                var work_id = id;
                var obj = $(this)[0];
                var index = obj.$input["0"].id;
                
                save(work_id,index);
            }
        },
        index:"",
    }


    var vm = new Vue({
        el : '#assign-bom',
        data : data
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>