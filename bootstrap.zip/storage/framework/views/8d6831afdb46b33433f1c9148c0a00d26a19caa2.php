<?php $__env->startSection('content-header'); ?>

<?php if($vendor->id): ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Vendors',
        'subtitle' => 'Edit',
        'items' => [
            'Home' => route('index'),
            'Vendors' => route('vendor.index'),
            $vendor->name => route('vendor.show',$vendor->id),
            'Edit' => route('vendor.edit',$vendor->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php else: ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Vendors',
        'subtitle' => 'Create',
        'items' => [
            'Home' => route('index'),
            'Vendors' => route('vendor.index'),
            'Create' => route('vendor.create'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if($vendor->id): ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('vendor.update',['id'=>$vendor->id])); ?>">
                    <input type="hidden" name="_method" value="PATCH">
                <?php else: ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('vendor.store')); ?>">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="box-body">

                        <div class="form-group">
                            <label for="code" class="col-sm-2 control-label">Vendor Code</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="code" name="code" required autofocus value="<?php echo e($vendor->code == null ? $vendor_code: $vendor->code); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Vendor Name</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="name" required autofocus value="<?php echo e($vendor->name); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="address" class="col-sm-2 control-label">Vendor Address</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="address" name="address" required value="<?php echo e($vendor->address); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="phone_number" class="col-sm-2 control-label">Phone Number</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="phone_number" name="phone_number" required value="<?php echo e($vendor->phone_number); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-sm-2 control-label">Email</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="email" name="email" required value="<?php echo e($vendor->email); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="status" class="col-sm-2 control-label">Vendor Status</label>
            
                            <div class="col-sm-10">
                                <select class="form-control" name="status" id="status" required>
                                    <option value="1">Active</option>
                                    <option value="0">Non Active</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <?php if($vendor->id): ?>
                            <button type="submit" class="btn btn-primary pull-right">Save</button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-primary pull-right">Create</button>
                        <?php endif; ?>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#status').val("<?php echo e($vendor->status); ?>");
        if($('#status').val()==null){
            $('#status').val(1);
        }
        $('#status').select({
            minimumResultsForSearch: -1
        });
        $('div.overlay').remove();
        $('.alert').addClass('animated bounce');
    });
    document.getElementById("code").readOnly = true;
    document.getElementById("volume").readOnly = true;

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>