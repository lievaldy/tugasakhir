<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View Storage Location',
        'subtitle' => 'Show',
        'items' => [
            'Dashboard' => route('index'),
            'View All Storage Locations' => route('storage_location.index'),
            $storage_location->name => route('storage_location.show',$storage_location->id),
            //'Show' => route('storage_location.show', ['id' => $storage_location->id]),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
            <div class="box-title"></div>
            <div class="box-tools pull-right p-t-5">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-storage-location')): ?>
                    <a href="<?php echo e(route('storage_location.edit',['id'=>$storage_location->id])); ?>" class="btn btn-primary btn-sm">EDIT</a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy-storage-location')): ?>
                        <button class="btn btn-danger btn-sm" onclick="event.preventDefault();document.getElementById('delete-form-<?php echo e($storage_location->id); ?>').submit();">DELETE</button>
                    <?php endif; ?>
                <form id="delete-form-<?php echo e($storage_location->id); ?>" action="<?php echo e(route('storage_location.destroy', ['id' => $storage_location->id])); ?>" method="POST" style="display: none;">
                    <input type="hidden" name="_method" value="DELETE">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered showTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Attribute</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Code</td>
                            <td><?php echo e($storage_location->code); ?></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Name</td>
                            <td><?php echo e($storage_location->name); ?></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Area (m2)</td>
                            <td><?php echo e($storage_location->area); ?></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Description</td>
                            <td><?php echo e($storage_location->description); ?></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Status</td>
                            <?php if($storage_location->status == 1): ?>
                                <td class ="iconTd"><i class="fa fa-check"></i></td>
                            <?php elseif($storage_location->status == 0): ?>
                                <td class ="iconTd"><i class="fa fa-times"></i></td>
                            <?php endif; ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>