<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View Company',
        'items' => [
            'Dashboard' => route('index'),
            'Companies' => route('company.index'), 
            $company->name => route('company.show',$company->id),
            // 'View' => route('company.show', ['id' => $company->id]),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
            <div class="box-title"></div>
            <div class="box-tools pull-right p-t-5">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-company')): ?>
                    <a href="<?php echo e(route('company.edit',['id'=>$company->id])); ?>" class="btn btn-primary btn-sm">EDIT</a>
                <?php endif; ?>

                
            </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered showTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Attribute</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Code</td>
                            <td><?php echo e($company->code); ?></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Name</td>
                            <td><?php echo e($company->name); ?></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Address</td>
                            <td><?php echo e($company->address); ?></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Phone Number</td>
                            <td><?php echo e($company->phone_number); ?></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Fax</td>
                            <td><?php echo e($company->fax); ?></td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>Email</td>
                            <td><?php echo e($company->email); ?></td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td>Status</td>
                            <td class="iconTd">
                                <?php if($company->status == 1): ?>
                                    <i class="fa fa-check"></i>
                                <?php elseif($company->status == 0): ?>
                                    <i class="fa fa-times"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>