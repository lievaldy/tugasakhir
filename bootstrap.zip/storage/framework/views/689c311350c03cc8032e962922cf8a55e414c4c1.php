<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Menus',
        'subtitle' => 'Index',
        'items' => [
            'Home' => route('index'),
            'Menus' => route('config.menus.index'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">List of Menus</h3>
                <div class="box-tools pull-right p-t-5">
                    <a href="<?php echo e(route('config.menus.create')); ?>" class="btn btn-primary btn-sm">Create</a>
                </div>
            </div> <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover" id="menus-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>URL</th>
                            <th>Icon</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($menu->id); ?></td>
                                <td><?php echo e($menu->name); ?></td>
                                <td><?php echo e($menu->route_name); ?></td>
                                <td><i class="fa <?php echo e($menu->icon); ?>"></i></td>
                                <td><a href="<?php echo e(route('config.menus.show', ['id'=>$menu->id])); ?>"><i class="fa fa-eye"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#menus-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>