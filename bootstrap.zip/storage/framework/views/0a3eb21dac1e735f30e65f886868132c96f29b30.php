<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Menus',
        'subtitle' => 'Show',
        'items' => [
            'Home' => route('index'),
            'Menus' => route('config.menus.index'),
            'Show' => route('config.menus.show', ['id' => $menu->id]),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
            <div class="box-title"></div>
            <div class="box-tools pull-right p-t-5">
                <a href="<?php echo e(route('config.menus.edit',['id'=>$menu->id])); ?>" class="btn btn-primary btn-sm">Edit</a>
                
                <button class="btn btn-danger btn-sm" onclick="event.preventDefault();document.getElementById('delete-form-<?php echo e($menu->id); ?>').submit();">Delete</button>

                <form id="delete-form-<?php echo e($menu->id); ?>" action="<?php echo e(route('config.menus.destroy', ['id' => $menu->id])); ?>" method="POST" style="display: none;">
                    <input type="hidden" name="_method" value="DELETE">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Attribute</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Level</td>
                            <td><?php echo e($menu->level); ?></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Name</td>
                            <td><?php echo e($menu->name); ?></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Icon</td>
                            <td><i class="fa <?php echo e($menu->icon); ?>"></i></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Route Name</td>
                            <td>
                                <?php if(Route::has($menu->route_name)): ?>
                                    <a target="_blank" href="<?php echo e(route($menu->route_name)); ?>"><?php echo e(route($menu->route_name)); ?></a>
                                <?php else: ?>
                                    No route specify for this menu
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Active</td>
                            <td><i class="fa <?php echo e($menu->is_active == 1 ? 'fa-check' : 'fa-times'); ?>"></i></td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>Roles</td>
                            <td><?php echo e($menu->roles); ?></td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td>Parent</td>
                            <td><?php echo e($menu->menu->name ?? 'This is a parent menu'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>