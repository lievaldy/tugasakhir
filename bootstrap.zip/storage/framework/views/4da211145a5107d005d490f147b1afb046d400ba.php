<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Physical Inventory » Begin Snapshot',
        'items' => [
            'Dashboard' => route('index'),
            'Begin Snapshot' =>"",
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box box-solid">
            <div class="box-body">
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#create_snapshot" data-toggle="tab" aria-expanded="true">Create Snapshot</a></li>
                        <li class=""><a href="#view_snapshot" data-toggle="tab" aria-expanded="false">View Snapshot Document</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="create_snapshot">
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('physical_inventory.displaySnapshot')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="box-body">
                
                                    <div class="form-group">
                                        <label for="sloc" class="col-sm-2 control-label">Storage Location</label>
                    
                                        <div class="col-sm-10">
                                            <select id="sloc" name="sloc[]" multiple="multiple">
                                                <?php $__currentLoopData = $storage_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storage_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($storage_location->id); ?>"><?php echo e($storage_location->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                    
                                    <div class="form-group">
                                        <label for="material" class="col-sm-2 control-label">Material</label>
                        
                                        <div class="col-sm-10">
                                            <select id="material" name="material[]" multiple="multiple">
                                                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($material->id); ?>"><?php echo e($material->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                    
                                </div>
                                <!-- /.box-body -->
                                <div class="box-footer">
                                    <button disabled id="display" type="submit" class="btn btn-primary col-sm-12">DISPLAY</button>
                                </div>
                                <!-- /.box-footer -->
                            </form>
                        </div>
                        <!-- /.tab-pane -->
                        <div class="tab-pane" id="view_snapshot">
                            <table id="stock-table" class="table table-bordered tableFixed" style="border-collapse:collapse; table-layout:fixed;">
                                <thead>
                                    <tr>
                                        <th class="p-l-5" style="width: 5%">No</th>
                                        <th style="width: 15%">Code</th>
                                        <th style="width: 20%">Created At</th>
                                        <th style="width: 20%">Status</th>
                                        <th style="width: 20%">Items</th>
                                        <th style="width: 20%"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php ($counter = 1); ?>
                                    <?php $__currentLoopData = $snapshots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $snapshot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="p-l-10"><?php echo e($counter++); ?></td>
                                            <td class="p-l-10"><?php echo e($snapshot->code); ?></td>
                                            <td class="p-l-10"><?php echo e($snapshot->created_at); ?></td>
                                            <td class="p-l-10">
                                                <?php if($snapshot->status == 1): ?>
                                                    Open
                                                <?php elseif($snapshot->status == 0): ?>
                                                    Closed
                                                <?php elseif($snapshot->status == 2): ?>
                                                    Counted
                                                <?php endif; ?>
                                            </td>
                                            <td class="p-l-10"><?php echo e(count($snapshot->snapshotDetails)); ?></td>
                                            <td class="p-l-0 textCenter">
                                                <button class="btn btn-primary btn-xs">
                                                    <a  href="<?php echo e(route('physical_inventory.showSnapshot', ['id' => $snapshot->id])); ?>">
                                                        VIEW
                                                    </a>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.tab-pane -->
                    </div>
                    <!-- /.tab-content -->
                </div>
            </div>
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('div.overlay').remove();
        $('#sloc, #material').multiselect({
            includeSelectAllOption: true,
            buttonWidth: '100%',
            enableFiltering: true,
            filterBehavior: 'text',
            enableCaseInsensitiveFiltering: true,
            maxHeight: 400,
            onChange: function(element, checked) {
                var sloc = $('#sloc').val();
                var material = $('#material').val();
                if(sloc.length > 0 && material.length > 0){
                    document.getElementById("display").disabled = false;
                }else{
                    document.getElementById("display").disabled = true;
                }
            }
        })

        $('#stock-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>