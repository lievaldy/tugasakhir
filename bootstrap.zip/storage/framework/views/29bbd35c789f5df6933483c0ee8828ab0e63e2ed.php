<?php $__env->startSection('content-header'); ?>
<?php if($menu == "create_po"): ?>
    <?php $__env->startComponent('components.breadcrumb', [
            'title' => 'Create Production Order » Select Project',
            'items' => [
                'Dashboard' => route('index'),
                'Select Project' => route('production_order.selectProject'),
            ]
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php elseif($menu == "release_po"): ?>
    <?php $__env->startComponent('components.breadcrumb', [
            'title' => 'Release Production Order » Select Project',
            'items' => [
                'Dashboard' => route('index'),
                'Select Project' => route('production_order.selectProjectRelease'),
            ]
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php elseif($menu == "confirm_po"): ?>
    <?php $__env->startComponent('components.breadcrumb', [
            'title' => 'Confirm Production Order » Select Project',
            'items' => [
                'Dashboard' => route('index'),
                'Select Project' => route('production_order.selectProjectConfirm'),
            ]
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php elseif($menu == "report_po"): ?>
    <?php $__env->startComponent('components.breadcrumb', [
            'title' => 'PO Actual Cost Report » Select Project',
            'items' => [
                'Dashboard' => route('index'),
                'Select Project' => route('production_order.selectProjectReport'),
            ]
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">List of Projects</h3>
            </div> <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered" id="boms-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="25%">Project Name</th>
                            <th width="40%">Customer</th>
                            <th width="25%">Ship</th>
                            <th width="5%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $modelProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($project->name); ?></td>
                                <td><?php echo e($project->customer->name); ?></td>
                                <td><?php echo e($project->ship->name); ?></td>
                                <?php if($menu == "create_po"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('production_order.selectWBS', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php elseif($menu == "release_po"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('production_order.selectWO', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php elseif($menu == "confirm_po"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('production_order.confirmWO', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php elseif($menu == "report_po"): ?>
                                    <td class="p-l-5 p-r-5" align="center">
                                        <a class="btn btn-primary btn-xs" href="<?php echo e(route('production_order.selectWOReport', ['id'=>$project->id])); ?>">SELECT</a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#boms-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>