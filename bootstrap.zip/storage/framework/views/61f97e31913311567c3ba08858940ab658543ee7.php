<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View Production Order » '.$modelPO->number,
        'items' => [
            'Dashboard' => route('index'),
            'View Production Order' => route('production_order.show',$modelPO->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-blue">
            <div class="row">
                <div class="col-sm-3 col-md-3">
                    <div class="info-box">
                        <span class="info-box-icon bg-blue">
                            <i class="fa fa-envelope"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">Prod. Order Number</span>
                            <span class="info-box-number"><?php echo e($modelPO->number); ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4 m-t-10">
                    <div class="row">
                        <div class="col-md-4">
                            Project Code
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e($modelPO->project->code); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Project Name
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e($modelPO->project->name); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Work Code
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e($modelPO->work->code); ?> </b>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4 m-t-10">
                    <div class="row">
                        <div class="col-md-5">
                            Status
                        </div>
                        <?php if($modelPO->status == 1): ?>
                            <div class="col-md-7">
                                : <b>UNRELEASED</b>
                            </div>
                        <?php elseif($modelPO->status == 2): ?>
                            <div class="col-md-7">
                                : <b>RELEASED</b>
                            </div>
                        <?php else: ?>
                            <div class="col-md-7">
                                : <b>COMPLETED</b>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="box-body p-t-0 p-b-5">
                    <h4>Material</h4>
                <table class="table table-bordered showTable" id="material-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="40%">Material Name</th>
                            <th width="25%">Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($counter=1); ?>
                        <?php $__currentLoopData = $modelPO->ProductionOrderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $POD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($POD->material_id != ""): ?>
                            <tr>
                                <td><?php echo e($counter); ?></td>
                                <td><?php echo e($POD->material->name); ?></td>
                                <td><?php echo e(number_format($POD->quantity)); ?></td>
                            </tr>
                        <?php ($counter++); ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->

            
            <div class="box-body p-t-0 p-b-5">
                    <table class="table table-bordered showTable" id="resource-table">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="40%">Resource Name</th>
                            </tr>
                        </thead>
                <h4>Resource</h4>
                        <tbody>
                            <?php ($counter=1); ?>
                            <?php $__currentLoopData = $modelPO->ProductionOrderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $POD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($POD->resource_id != ""): ?>
                                <tr>
                                    <td><?php echo e($counter); ?></td>
                                    <td><?php echo e($POD->resource ->name); ?></td>
                                </tr>
                                <?php ($counter++); ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('div.overlay').hide();
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>