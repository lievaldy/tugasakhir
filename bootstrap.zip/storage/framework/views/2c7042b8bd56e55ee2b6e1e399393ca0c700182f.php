<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Material',
        'subtitle' => 'Show',
        'items' => [
            'Dashboard' => route('index'),
            'View All Materials' => route('material.index'),
            $material->name => route('material.show',$material->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
                <div class="box-title"></div>
                <div class="box-tools pull-right p-t-5">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-material')): ?>
                        <a href="<?php echo e(route('material.edit',['id'=>$material->id])); ?>" class="btn btn-primary btn-sm">EDIT</a>
                    <?php endif; ?>

                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy-material')): ?>
                        <button class="btn btn-danger btn-sm" onclick="event.preventDefault();document.getElementById('delete-form-<?php echo e($material->id); ?>').submit();">DELETE</button>
                    <?php endif; ?>

                    <form id="delete-form-<?php echo e($material->id); ?>" action="<?php echo e(route('material.destroy', ['id' => $material->id])); ?>" method="POST" style="display: none;">
                        <input type="hidden" name="_method" value="DELETE">
                        <?php echo csrf_field(); ?>
                    </form> -->
                </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered width100 showTable tableFixed">
                    <thead>
                        <tr>
                            <th style="width: 5%">#</th>
                            <th style="width: 35%">Attribute</th>
                            <th style="width: 60%">Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Code</td>
                            <td><?php echo e($material->code); ?></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Name</td>
                            <td><?php echo e($material->name); ?></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Description</td>
                            <td class="tdEllipsis" data-container="body" data-toggle="tooltip" title="<?php echo e($material->description); ?>"><?php echo e($material->description); ?></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Cost Standard Price</td>
                            <td><?php echo e($material->cost_standard_price); ?></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Weight</td>
                            <td><?php echo e($material->weight); ?></td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>Height</td>
                            <td><?php echo e($material->height); ?></td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td>Length</td>
                            <td><?php echo e($material->length); ?></td>
                        </tr>
                        <tr>
                            <td>8</td>
                            <td>Width</td>
                            <td><?php echo e($material->width); ?></td>
                        </tr>
                        <tr>
                            <td>9</td>
                            <td>Volume</td>
                            <td><?php echo e($material->volume); ?></td>
                        </tr>
                        <tr>
                            <td>10</td>
                            <td>Type</td>
                            <?php if($material->type == 3): ?>
                                <td>Bulk part</td>
                            <?php elseif($material->type == 2): ?>
                                <td>Component</td>
                            <?php elseif($material->type == 1): ?>
                                <td>Consumable</td>
                            <?php elseif($material->type == 0): ?>
                                <td>Raw</td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <td>11</td>
                            <td>Status</td>
                            <td class="iconTd">
                                <?php if($material->status == 1): ?>
                                    <i class="fa fa-check"></i>
                                <?php elseif($material->status == 0): ?>
                                    <i class="fa fa-times"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>