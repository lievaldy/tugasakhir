<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="initial-scale=1.0">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>ERP - PATRIA</title>

        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" type="text/css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
        <?php echo $__env->yieldPushContent('style'); ?>
    </head>
    <body class="<?php echo e($defaultSkin->default ?? 'skin-blue'); ?> sidebar-mini fixed">
        <div class="wrapper">
            <header class="main-header">
                <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </header>

            <!-- Left side column. contains the logo and sidebar -->
            <aside class="main-sidebar">
                <?php echo $__env->make('includes.sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </aside>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">

                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <?php echo $__env->yieldContent('content-header'); ?>
                </section>

                <!-- Main content -->
                <section class="content p-b-0">
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
                <!-- /.content -->
            </div>

            <!-- /.content-wrapper -->
            <footer class="main-footer">
                <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </footer>

            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
                <!-- Create the tabs -->
                <ul class="nav nav-tabs nav-justified control-sidebar-tabs"></ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <!-- Home tab content -->
                    <div class="tab-pane" id="control-sidebar-home-tab"></div>
                <!-- /.tab-pane -->
                </div>
            </aside>

            <!-- /.control-sidebar -->
            <div class="control-sidebar-bg"></div>
        </div>
        
        <!-- ./wrapper -->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script>
            $(function () {
                <?php echo $__env->make('components.iziToast', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
            });
        </script>
        <?php echo $__env->yieldPushContent('script'); ?>
    </body>
</html>
