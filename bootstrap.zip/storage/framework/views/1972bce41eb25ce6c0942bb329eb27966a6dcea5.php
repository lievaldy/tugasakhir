<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Create Role',
        'items' => [
            'Dashboard' => route('index'),
            'View All Roles' => route('role.index'),
            'Create Role' => route('role.create'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form id="create-role" class="form-horizontal" method="POST" action="<?php echo e(route('role.store')); ?>">
                <?php echo csrf_field(); ?>
                    
                    <div id="role">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Name</label>
                                <div class="col-sm-10">
                                    <input v-model="submittedForm.name" type="text" class="form-control" id="name" name="name" required autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="description" class="col-sm-2 control-label">Description</label>
                                <div class="col-sm-10">
                                    <input v-model="submittedForm.description" type="text" class="form-control" id="description" name="description" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div v-for ="menu in menus">
                                <a href="" @click.prevent="getMenu(menu)">
                                    <div class="box box-solid no-margin m-b-10 ">
                                        <div class="box-header with-border" :id="menu.id">
                                            <span>{{ menu.name }}</span>
                                            <i class="fa fa-angle-double-right pull-right"></i>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
        
                        <div class="col-md-9">
                            <template v-for="sub_menu in sub_menus">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h3 class="box-title">{{ sub_menu.name }}</h3>
                                    </div>
                                    <div class="box-body">
                                        <div class="col-md-6">
                                            <template v-for="permission in permissionsLeft">
                                                <template v-if="permission.menu_id == sub_menu.id">
                                                    <div class="p-t-10 p-l-10"><input type="checkbox" v-icheck="" v-model="checkedPermissions" :value="permission.middleware"> <span>{{ permission.name }}</span></div>
                                                </template>
                                            </template>
                                        </div>
                                        <div class="col-md-6">
                                            <template v-for="permission in permissionsRight">
                                                <template v-if="permission.menu_id == sub_menu.id">
                                                    <div class="p-t-10 p-l-10"><input type="checkbox" v-icheck="" v-model="checkedPermissions" :value="permission.middleware"> <span>{{ permission.name }}</span></div>
                                                </template>
                                            </template>
                                        </div>
                                    </div>
                                </div>
                            </template>
                        </div>
                        <div class="row">
                            <div class="col-md-12 p-t-30">
                                <button @click.prevent="submitForm" class="btn btn-primary pull-right" :disabled="createOk">CREATE</button>
                            </div>
                        </div>
                    </div>
                    
                </form>
            </div>
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
<script>
    const form = document.querySelector('form#create-role');

    $(document).ready(function(){
        $('div.overlay').hide();
        $('.alert').addClass('animated bounce');
        
    });

    var data = {
       menus : <?php echo json_encode($menus, 15, 512) ?>,
       menu_id : "",
       permissionsLeft : [],
       permissionsRight : [],
       sub_menus : [],
       checkedPermissions : [],
       submittedForm : {
           name : "",
           description : "",
           permissions : [],
           checkedPermissions : []
       },
    }

    var app = new Vue({
        el : '#role',
        data : data,
        computed:{
            createOk: function(){
                let isOk = false;

                if(this.submittedForm.name == "" || this.checkedPermissions.length < 1){
                    isOk = true;
                }
                return isOk;
            },
        },
        directives: {
            icheck: {
                inserted: function(el, b, vnode) {
                    var vdirective = vnode.data.directives,
                    vModel;
                    for (var i = 0, vDirLength = vdirective.length; i < vDirLength; i++) {
                    if (vdirective[i].name == "model") {
                        vModel = vdirective[i].expression;
                        break;
                    }
                    }
                    jQuery(el).iCheck({
                    checkboxClass: "icheckbox_square-blue",
                    radioClass: "iradio_square-blue",
                    increaseArea: "20%" // optional
                    });

                    jQuery(el).on("ifChanged", function(e) {
                    if ($(el).attr("type") == "radio") {
                        app.$data[vModel] = $(this).val();
                    }
                    if ($(el).attr("type") == "checkbox") {
                        let data = app.$data[vModel];

                        $(el).prop("checked")
                        ? app.$data[vModel].push($(this).val())
                        : data.splice(data.indexOf($(this).val()), 1);
                    }
                    });
                }
            }
        }, 
        methods: {
            getMenu(menu){
                if(this.menu_id != ""){
                    document.getElementById(this.menu_id).className = "box-header with-border";
                }
                this.sub_menus = [];
                this.menu_id = menu.id;
                document.getElementById(menu.id).className = "box-header with-border bg-aqua";

                this.getSubMenu(menu.id);
                this.getPermission(menu.id);
                if(this.sub_menus.length == 0){
                    this.sub_menus.push(menu);
                }
                
            },
            getPermission(id_menu){
                $('div.overlay').show();
                window.axios.get('/api/getPermission/'+id_menu).then(({ data }) => {
                    this.permissionsLeft = [];
                    this.permissionsRight = [];
                    for (var i = 0; i < data.length; i++) {
                        if(i % 2 === 0) { // index is even
                            this.permissionsLeft.push(data[i]);
                        }else{
                            this.permissionsRight.push(data[i]);
                        }
                    }
                    $('div.overlay').hide();
                    
                })
                .catch((error) => {
                    iziToast.warning({
                        title: 'Please Try Again..',
                        position: 'topRight',
                        displayMode: 'replace'
                    });
                    console.log(error);
                    $('div.overlay').hide();
                })
            },
            getSubMenu(id_menu){
                window.axios.get('/api/getSubMenu/'+id_menu).then(({ data }) => {
                    if(data.length > 0){
                        this.sub_menus = [];
                        this.sub_menus = data;
                    }
                })
                .catch((error) => {
                    iziToast.warning({
                        title: 'Please Try Again..',
                        position: 'topRight',
                        displayMode: 'replace'
                    });
                    console.log(error);
                    $('div.overlay').hide();
                })
            },
            submitForm(){
                var permission = this.checkedPermissions;
                var jsonPermission = JSON.stringify(permission);
                jsonPermission = JSON.parse(jsonPermission);
                this.submittedForm.checkedPermissions = jsonPermission;

                for(var i in permission){
                    permission[i] = '"'+permission[i]+'":true';
                    this.submittedForm.permissions.push(permission[i]);
                }
                

                let struturesElem = document.createElement('input');
                struturesElem.setAttribute('type', 'hidden');
                struturesElem.setAttribute('name', 'datas');
                struturesElem.setAttribute('value', JSON.stringify(this.submittedForm));
                form.appendChild(struturesElem);
                form.submit();
            }
        },
    });
       
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>