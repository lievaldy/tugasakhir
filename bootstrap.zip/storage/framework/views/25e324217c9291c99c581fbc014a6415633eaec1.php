<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View Branch',
        'items' => [
            'Dashboard' => route('index'),
            'View All Branches' => route('branch.index'),
            $branch->name => route('branch.show',$branch->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <div class="box">
            <div class="box-header">
                <div class="box-title"></div>
                <div class="box-tools pull-right p-t-5">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-branch')): ?>
                        <a href="<?php echo e(route('branch.edit',['id'=>$branch->id])); ?>" class="btn btn-primary btn-sm">EDIT</a>
                    <?php endif; ?>

                    <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy-branch')): ?>
                        <button class="btn btn-danger btn-sm" onclick="event.preventDefault();document.getElementById('delete-form-<?php echo e($branch->id); ?>').submit();">DELETE</button>
                    <?php endif; ?>

                    <form id="delete-form-<?php echo e($branch->id); ?>" action="<?php echo e(route('branch.destroy', ['id' => $branch->id])); ?>" method="POST" style="display: none;">
                        <input type="hidden" name="_method" value="DELETE">
                        <?php echo csrf_field(); ?>
                    </form> -->
                </div>
            </div>
            <div class="box-body">
                <table class="table table-bordered width100 showTable tableFixed">
                    <thead>
                        <tr>
                            <th style="width: 5%">#</th>
                            <th style="width: 35%">Attribute</th>
                            <th style="width: 60%">Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Code</td>
                            <td><?php echo e($branch->code); ?></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Name</td>
                            <td><?php echo e($branch->name); ?></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Address</td>
                            <td class="wordWrap"><?php echo e($branch->address); ?></td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Phone Number</td>
                            <td><?php echo e($branch->phone_number); ?></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Fax</td>
                            <td><?php echo e($branch->fax); ?></td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>Email</td>
                            <td><?php echo e($branch->email); ?></td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td>Company</td>
                            <td><?php echo e($branch->company->name); ?></td>
                        </tr>
                        <tr>
                            <td>8</td>
                            <td>Status</td>
                            <td class="iconTd">
                                <?php if($branch->status == 1): ?>
                                        <i class="fa fa-check"></i>
                                <?php elseif($branch->status == 0): ?>
                                    <i class="fa fa-times"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>