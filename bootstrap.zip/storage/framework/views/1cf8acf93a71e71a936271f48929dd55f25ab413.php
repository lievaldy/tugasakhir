<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Menus',
        'subtitle' => 'Create',
        'items' => [
            'Home' => route('index'),
            'Menus' => route('config.menus.index'),
            'Create' => route('config.menus.create'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if($menu->id): ?>
                <form class="form-horizontal" method="POST" action="<?php echo e(route('config.menus.update',['id'=>$menu->id])); ?>">
                <input type="hidden" name="_method" value="PATCH">
                <?php else: ?>
                <form class="form-horizontal" method="POST" action="<?php echo e(route('config.menus.store')); ?>">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="box-body">
                        <div class="form-group">
                        <label for="level" class="col-sm-2 control-label">Level</label>
        
                        <div class="col-sm-10">
                            <input type="number" class="form-control" id="level" name="level" required autofocus value="<?php echo e($menu->level); ?>">
                        </div>
                        </div>

                        <div class="form-group">
                        <label for="name" class="col-sm-2 control-label">Name</label>
        
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="name" name="name" required value="<?php echo e($menu->name); ?>">
                        </div>
                        </div>

                        <div class="form-group">
                        <label for="icon" class="col-sm-2 control-label">Icon</label>
        
                        <div class="col-sm-10">
                            <select class="form-control" name="icon" id="icon" required>
                                <option></option>
                                <?php $__currentLoopData = $fontAwesomeIcons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($icon); ?>"><?php echo e($icon); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        </div>

                        <div class="form-group">
                        <label for="route_name" class="col-sm-2 control-label">Route Name</label>
        
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="route_name" name="route_name" required value="<?php echo e($menu->route_name); ?>">
                        </div>
                        </div>

                        <div class="form-group">
                        <label for="is_active" class="col-sm-2 control-label">Active</label>
        
                        
                        <div class="col-sm-10">
                            <div class="checkbox icheck">
                            <label>
                                <input type="hidden" name="is_active" value="0">
                                <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e($menu->is_active == 0 ? '' : 'checked'); ?>>
                            </label>
                            </div>
                        </div>
                        </div>
                        
                        <div class="form-group">
                        <label for="roles" class="col-sm-2 control-label">Roles</label>
        
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="roles" name="roles" required value="<?php echo e($menu->roles); ?>">
                        </div>
                        </div>

                        <div class="form-group">
                        <label for="parent_id" class="col-sm-2 control-label">Parent</label>
        
                        <div class="col-sm-10">
                            <select class="form-control" name="parent_id" id="parent_id">
                                <option></option>
                                <?php $__currentLoopData = $parentMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary pull-right">Create</button>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#parent_id').val("<?php echo e($menu->menu_id); ?>");
        $('#icon').val("<?php echo e($menu->icon); ?>");
        $('#parent_id').select2({
            placeholder: "Select Parent Menu",
            allowClear: true,
        });
        $('#icon').select2({
            placeholder: "Select Icon",
            allowClear: true,
        });
        $('div.overlay').remove();
        $('.alert').addClass('animated bounce');
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>