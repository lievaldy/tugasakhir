<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'BOM',
        'subtitle' => 'Create',
        'items' => [
            'Home' => route('index'),
            'BOM' => route('bom.index'),
            'Create' => route('bom.create'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-solid">
            <div class="box-body">
                <form id="create-bom" class="form-horizontal" method="POST" action="<?php echo e(route('bom.store')); ?>">
                <?php echo csrf_field(); ?>
                    
                    <div id="bom">
                        <div class="form-group p-t-20">
                            <div class="col-md-12">
                                <div class="col-md-1 p-t-5">
                                    <label>Project</label>
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" disabled :value="project.name">
                                </div>
                                <div class="col-md-7 pull-right ">
                                    <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modal-default" >
                                        ADD BOM
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-12 p-t-20">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th width="5%">No</th>
                                        <th width="25%">Structure</th>
                                        <th width="25%">Sub Structure</th>
                                        <th width="25%">Material</th>
                                        <th width="10%">Quantity</th>
                                        <th width="10%" ></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(data, index) in dataTable">
                                        <td>{{ index + 1 }}</td>
                                        <td>{{ data.structure_name }}</td>
                                        <td>{{ data.sub_structure }}</td>
                                        <td>{{ data.material }}</td>
                                        <td>{{ data.quantity }}</td>
                                        <td align="center"><a href="#" @click="removeRow(index)">
                                            <div class="btn-group">
                                                <i class="fa fa-close"></i>
                                            </div></a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="col-md-12">
                            <button @click.prevent="submitForm" class="btn btn-primary pull-right" :disabled="createOk">CREATE</button>
                        </div>

                        <div class="modal fade" id="modal-default" style="display: none;">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span></button>
                                        <h4 class="modal-title">Add BOM</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="structure" class="col-sm-3 control-label">Structure</label>
                            
                                            <div class="col-sm-9">
                                                <selectize id="structure" v-model="dataModal.structure_id" :settings="structureSettings">
                                                    <option v-for="(structure, index) in structures" :value="structure.id">{{ structure.name }}</option>
                                                </selectize>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="subStructure" class="col-sm-3 control-label">Sub Structure</label>
                            
                                            <div class="col-sm-9">
                                                <selectize id="subStructure" v-model="dataModal.sub_structure" :settings="subStructureSettings">
                                                    <option v-for="(subStructure, index) in subStructures" :value="subStructure.name">{{ subStructure.name }}</option>
                                                </selectize>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="material" class="col-sm-3 control-label">Material</label>
                            
                                            <div class="col-sm-9">
                                                <selectize id="material" v-model="dataModal.material" :settings="materialSettings">
                                                    <option v-for="(material, index) in materials" :value="material.name">{{ material.name }}</option>
                                                </selectize>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="quantity" class="col-sm-3 control-label">Quantity</label>
                            
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" id="quantity" name="quantity" required v-model="dataModal.quantity">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button data-dismiss="modal" type="button" class="btn btn-primary" @click="submitToTable()" :disabled="modalOk">SUBMIT</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </form>
            </div>
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    const form = document.querySelector('form#create-bom');

    $(document).ready(function(){
        $('div.overlay').hide();
        $('.alert').addClass('animated bounce');
        
    });

    var data = {
        project : <?php echo json_encode($project, 15, 512) ?>,
        materials : <?php echo json_encode($materials, 15, 512) ?>,
        structures : <?php echo json_encode($structures, 15, 512) ?>,
        subStructures : [],
        submittedForm :{},
        dataModal :{
            material : "",
            structure_id : "",
            structure_name : "",
            sub_structure : "",
            quantity : ""
        },
        dataTable : [],
        materialSettings: {
            placeholder: 'Please Select Material'
        },
        structureSettings: {
            placeholder: 'Please Select Structure'
        },
        subStructureSettings: {
            placeholder: 'Please Select Sub Structure'
        },
    }

    var vm = new Vue({
        el : '#bom',
        data : data,
        computed:{
            createOk: function(){
                let isOk = false;

                if(this.dataTable.length < 1){
                    isOk = true;
                }
                return isOk;
            },
            modalOk: function(){
                let isOk = false;

                if(this.dataModal.material == "" || this.dataModal.structure_id == "" || this.dataModal.structure_name == "" || this.dataModal.sub_structure == "" || this.dataModal.quantity == ""){
                    isOk = true;
                }
                return isOk;
            },
            materialOk: function(){
                let isOk = false;

                if(this.submittedForm.material_id == ""){
                    isOk = true;
                }
                return isOk;
            },
        },
        methods: {
            submitForm(){
                this.submittedForm = this.dataTable;

                let struturesElem = document.createElement('input');
                struturesElem.setAttribute('type', 'hidden');
                struturesElem.setAttribute('name', 'datas');
                struturesElem.setAttribute('value', JSON.stringify(this.submittedForm));
                form.appendChild(struturesElem);
                form.submit();
            },
            submitToTable(){
                var data = JSON.stringify(this.dataModal);
                data = JSON.parse(data);
                this.dataTable.push(data);

                this.dataModal.material = "";
                this.dataModal.structure_id = "";
                this.dataModal.structure_name = "";
                this.dataModal.sub_structure = "";
                this.dataModal.quantity = "";

            },
            removeRow: function(index) {
                this.dataTable.splice(index, 1);
            }
        },
        watch: {
            'dataModal.structure_id': function(newValue){
                this.subStructures = [];
                
                window.axios.get('/api/getSubStructure/'+newValue).then(({ data }) => {
                    console.log(data);
                    this.dataModal.structure_name = data[0].structure.name;
                    this.subStructures = data;
                });

                var $subStructure = $(document.getElementById('subStructure')).selectize();
                $subStructure[0].selectize.focus();
            }
        },
    });
       
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>