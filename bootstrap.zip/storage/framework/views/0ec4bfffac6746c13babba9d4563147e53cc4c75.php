<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View Goods Receipt » '.$modelGR->number,
        'items' => [
            'Dashboard' => route('index'),
            'View Goods Receipt' => route('purchase_order.show',$modelGR->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-blue">
            <div class="row">
                <div class="col-sm-3 col-md-3">
                    <div class="info-box">
                        <span class="info-box-icon bg-blue">
                            <i class="fa fa-envelope"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">GR Number</span>
                            <span class="info-box-number"><?php echo e($modelGR->number); ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4 m-t-10">
                    <div class="row">
                        <div class="col-md-4">
                            Project Name
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e(isset($modelGR->purchaseOrder) ? $modelGR->purchaseOrder->project->name :  '-'); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            PO Code
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e(isset($modelGR->purchaseOrder) ? $modelGR->purchaseOrder->number : '-'); ?> </b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            Vendor Name
                        </div>
                        <div class="col-md-8">
                            : <b> <?php echo e(isset($modelGR->purchaseOrder) ? $modelGR->purchaseOrder->vendor->name : '-'); ?> </b>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-4 m-t-10">
                    <div class="row">
                        <div class="col-md-5">
                                Description
                            </div>
                            <div class="col-md-7">
                                : <b> <?php echo e($modelGR->description); ?> </b>
                            </div>
                    </div>
                </div>
            
            <div class="box-body p-t-0 p-b-0">
                <table class="table table-bordered showTable" id="gr-table">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th width="40%">Material Name</th>
                            <th width="25%">Quantity</th>
                            <th width="30%">Storage Location</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $modelGRD; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GRD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($GRD->material->name); ?></td>
                            <td><?php echo e(number_format($GRD->quantity)); ?></td>
                            <td><?php echo e($GRD->storageLocation->name); ?> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#gr-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>