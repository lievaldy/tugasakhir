<div class="pull-right hidden-xs">
    <b>Version</b> Alpha 0.1
</div>
<strong>Copyright &copy; <?php echo e(date('Y')); ?></strong> Ishak Antony, Yonathan Setiawan.