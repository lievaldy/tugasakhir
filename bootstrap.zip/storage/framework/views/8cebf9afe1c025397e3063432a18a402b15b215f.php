<?php $__env->startSection('content-header'); ?>

<?php if($ship->id): ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Ships',
        'subtitle' => 'Edit',
        'items' => [
            'Home' => route('index'),
            'Ships' => route('ship.index'),
            $ship->name => route('ship.show',$ship->id),
            'Edit' => route('ship.edit',$ship->id),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php else: ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'Ships',
        'subtitle' => 'Create',
        'items' => [
            'Home' => route('index'),
            'Ships' => route('ship.index'),
            'Create' => route('ship.create'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if($ship->id): ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('ship.update',['id'=>$ship->id])); ?>">
                    <input type="hidden" name="_method" value="PATCH">
                <?php else: ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('ship.store')); ?>">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="box-body">

                        <div class="form-group">
                            <label for="code" class="col-sm-2 control-label">Ship Code</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="code" name="code" required autofocus value="<?php echo e($ship->code == null ? $ship_code: $ship->code); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Ship Name</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="name" required autofocus value="<?php echo e($ship->name); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="type" class="col-sm-2 control-label">Ship Type</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="type" name="type" required value="<?php echo e($ship->type); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="description" class="col-sm-2 control-label">Ship Description</label>
            
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="description" name="description" required value="<?php echo e($ship->description); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="status" class="col-sm-2 control-label">Ship Status</label>
            
                            <div class="col-sm-10">
                                <select class="form-control" name="status" id="status" required>
                                    <option value="1">Active</option>
                                    <option value="0">Non Active</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <?php if($ship->id): ?>
                            <button type="submit" class="btn btn-primary pull-right">Save</button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-primary pull-right">Create</button>
                        <?php endif; ?>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('div.overlay').hide();
        $('#status').val("<?php echo e($ship->status); ?>");
        if($('#status').val()==null){
            $('#status').val(1);
        }
        
        $('#status').select({
            minimumResultsForSearch: -1
        });
        $('div.overlay').remove();
        $('.alert').addClass('animated bounce');
    });
    document.getElementById("code").readOnly = true;
    
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>