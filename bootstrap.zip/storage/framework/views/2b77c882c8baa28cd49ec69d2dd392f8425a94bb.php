<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="error-page">
        <h2 class="headline text-yellow"> 403</h2><br>
        <div class="error-content">
            <h3><i class="fa fa-warning text-yellow"></i> Whoops! Error Page.</h3>
            <p>
                You Are Not Authorized to Perform This Action.
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>