<?php $__env->startSection('content-header'); ?>
<?php $__env->startComponent('components.breadcrumb', [
        'title' => 'View All Permissions',
        'items' => [
            'Dashboard' => route('index'),
            'View All Permissions' => route('permission.index'),
        ]
    ]); ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header m-b-15">
                <div class="box-tools pull-right p-t-5">
                    <a href="<?php echo e(route('permission.create')); ?>" class="btn btn-primary btn-sm">CREATE</a>
                </div>
            </div> <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover" id="permissions-table">
                    <thead>
                        <tr>
                            <th style="width: 5%">No</th>
                            <th style="width: 35%">Name</th>
                            <th style="width: 35%">Middleware</th>
                            <th style="width: 15%">Menu</th>
                            <th style="width: 10%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($counter = 1); ?>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($counter++); ?></td>
                                <td><?php echo e($permission->name); ?></td>
                                <td><?php echo e($permission->middleware); ?></td>
                                <td><?php echo e($permission->menu->name); ?></td>
                                <td class="p-l-0 p-r-0" align="center">
                                    <a href="<?php echo e(route('permission.show', ['id'=>$permission->id])); ?>" class="btn btn-primary btn-xs">VIEW</a>
                                    <a href="<?php echo e(route('permission.edit', ['id'=>$permission->id])); ?>" class="btn btn-primary btn-xs">EDIT</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- /.box-body -->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
        </div> <!-- /.box -->
    </div> <!-- /.col-xs-12 -->
</div> <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function(){
        $('#permissions-table').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : true,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'initComplete': function(){
                $('div.overlay').remove();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>