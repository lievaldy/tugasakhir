<?php
    $name = Route::currentRouteName();
    $index = array_search($name, array_column($menusInfo, 'route'));
?>
<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
<ul class="sidebar-menu" data-widget="tree">
<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($menu->menus->count() > 0): ?>
<li class="treeview <?php echo e($menu->id == $menusInfo[$index]['parent1'] ? 'active' : ''); ?>">
    <a href="#">
        <i class="fa <?php echo e($menu->icon); ?>"></i>
        <?php if(strlen($menu->name) > 22): ?>
            <span><?php echo e(substr($menu->name, 0, 22)); ?>...</span>
        <?php else: ?>
            <span><?php echo e($menu->name); ?></span>
        <?php endif; ?>
        <span class="pull-right-container">
        <span class="label label-primary pull-right"><?php echo e($menu->menus->count()); ?></span>
        </span>
    </a>
    <ul class="treeview-menu">
        <?php $__currentLoopData = $menu->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($menu2->menus->count() > 0): ?>
            <li class="treeview <?php echo e($menu2->id == $menusInfo[$index]['parent2'] ? 'active' : ''); ?>">
                    <a href="#"><i class="fa <?php echo e($menu2->icon); ?>"></i>
                        <?php if(strlen($menu2->name) > 18): ?>
                            <span><?php echo e(substr($menu2->name, 0, 18)); ?>...</span>
                        <?php else: ?>
                            <span><?php echo e($menu2->name); ?></span>
                        <?php endif; ?>
                        <span class="pull-right-container">
                        <span class="label label-primary pull-right"><?php echo e($menu2->menus->count()); ?></span>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php $__currentLoopData = $menu2->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($menu3->id == $menusInfo[$index]['menu_id'] ? 'active' : ''); ?>"><a href="<?php echo e(route($menu3->route_name)); ?>"><i class="fa <?php echo e($menu3->icon); ?>"></i>
                            <?php if(strlen($menu3->name) > 15): ?>
                                <span><?php echo e(substr($menu3->name, 0, 15)); ?>...</span>
                            <?php else: ?>
                                <span><?php echo e($menu3->name); ?></span>
                            <?php endif; ?>
                            <?php if($menu3->created_at->diffInDays(date('Y-m-d')) == 0): ?>
                                <small class="label pull-right bg-green">New</small>
                            <?php endif; ?>
                            </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            </li>
            <?php else: ?>
            <li class="<?php echo e($menu2->id == $menusInfo[$index]['menu_id'] ? 'active' : ''); ?>">
            <a href="<?php echo e(Route::has($menu2->route_name) ? route($menu2->route_name) : '#'); ?>">
                <i class="fa <?php echo e($menu2->icon); ?>"></i> <span><?php echo e($menu2->name); ?></span>
                <span class="pull-right-container">
                <?php if($menu2->created_at->diffInDays(date('Y-m-d')) == 0): ?>
                    <small class="label pull-right bg-green">New</small>
                <?php endif; ?>
                </span>
            </a>
            </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</li>
<?php else: ?>
<li class="<?php echo e($menu->id == $menusInfo[$index]['menu_id'] ? 'active' : ''); ?>">
<a href="<?php echo e(Route::has($menu->route_name) ? route($menu->route_name) : '#'); ?>">
    <i class="fa <?php echo e($menu->icon); ?>"></i> <span><?php echo e($menu->name); ?></span>
    <span class="pull-right-container">
    <?php if($menu->created_at->diffInDays(date('Y-m-d')) == 0): ?>
        <small class="label pull-right bg-green">New</small>
    <?php endif; ?>
    </span>
</a>
</li>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</section>
<!-- /.sidebar -->










































