<div class="pull-right hidden-xs">
    <b>Version</b> Alpha 0.1
</div>
<strong>Copyright &copy; {{ date('Y') }}</strong> LPPM ITHB.