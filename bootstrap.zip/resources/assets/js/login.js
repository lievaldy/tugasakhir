window.$ = window.jQuery = require('jquery');

require('admin-lte/bower_components/bootstrap/dist/js/bootstrap.min.js');
require('admin-lte/plugins/iCheck/icheck.min.js');