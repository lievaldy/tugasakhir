<?php

use Illuminate\Database\Seeder;
use App\Models\Menu; 

class MenusTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Dashboard',
            'icon' => 'fa-dashboard',
            'route_name' => 'index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Project Management',
            'icon' => 'fa-calendar',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d'),
        ]);

        $projectManagement =  Menu::where('name','Project Management')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Manage Projects',
            'icon' => 'fa-calendar',
            'route_name'=> 'project.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=> $projectManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Confirm Activity',
            'icon' => 'fa-clock-o',
            'route_name'=> 'project.indexConfirm',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=> $projectManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'WBS & Estimator Configuration',
            'icon' => 'fa-clock-o',
            'route_name'=> 'project.selectProjectConfig',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=> $projectManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);
        
        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Bill Of Material',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        $bom =  Menu::where('name','Bill Of Material')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Create BOM',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'bom.indexProject',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=> $bom,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

             DB::table('menus')->insert([
            'level' => 2,
            'name' => 'View BOM',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'bom.selectProject',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=> $bom,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Cost Plan',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        $costPlan =  Menu::where('name','Cost Plan')->select('id')->first()->id;
        // DB::table('menus')->insert([
        //     'level' => 2,
        //     'name' => 'Create RAB',
        //     'icon' => 'fa-file-text-o',
        //     'route_name'=> 'rab.selectProject',
        //     'is_active' => true,
        //     'roles' => 'ADMIN',
        //     'menu_id'=>$costPlan,
        //     'created_at' => date('Y-m-d'),
        //     'updated_at' => date('Y-m-d')
        // ]);
        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'View RAP',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'rab.indexSelectProject',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$costPlan,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        // DB::table('menus')->insert([
        //     'level' => 2,
        //     'name' => 'View RAB',
        //     'icon' => 'fa-file-text-o',
        //     'route_name'=> 'rab.indexSelectProject',
        //     'is_active' => true,
        //     'roles' => 'ADMIN',
        //     'menu_id'=>$costPlan,
        //     'created_at' => date('Y-m-d'),
        //     'updated_at' => date('Y-m-d')
        // ]);
        

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Create Cost',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'rab.selectProjectCost',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$costPlan,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Assign Cost',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'rab.selectProjectAssignCost',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$costPlan,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'View Planned Cost',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'rab.selectProjectViewCost',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$costPlan,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'View Remaining Material',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'rab.selectProjectViewRM',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$costPlan,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Material Management',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        $materialManagement =  Menu::where('name','Material Management')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Purchase Requisition',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        $purchaseRequisition =  Menu::where('name','Purchase Requisition')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Create PR',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'purchase_requisition.create',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$purchaseRequisition,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Approve PR',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'purchase_requisition.indexApprove',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$purchaseRequisition,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'View PR',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'purchase_requisition.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$purchaseRequisition,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Purchase Order',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        $purchaseOrder =  Menu::where('name','Purchase Order')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Create PO',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'purchase_order.selectPR',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$purchaseOrder,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        // DB::table('menus')->insert([
        //     'level' => 3,
        //     'name' => 'Create PO Resource',
        //     'icon' => 'fa-file-text-o',
        //     'route_name'=> 'purchase_order.createPOResource',
        //     'is_active' => true,
        //     'roles' => 'ADMIN',
        //     'menu_id'=>$purchaseOrder,
        //     'created_at' => date('Y-m-d'),
        //     'updated_at' => date('Y-m-d')
        // ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Approve PO',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'purchase_order.indexApprove',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$purchaseOrder,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'View PO',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'purchase_order.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$purchaseOrder,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Goods Receipt',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        $goodsReceipt =  Menu::where('name','Goods Receipt')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Create GR',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'goods_receipt.createGrWithRef',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$goodsReceipt,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        // DB::table('menus')->insert([
        //     'level' => 3,
        //     'name' => 'Create GR without reference',
        //     'icon' => 'fa-file-text-o',
        //     'route_name'=> 'goods_receipt.createGrWithoutRef',
        //     'is_active' => true,
        //     'roles' => 'ADMIN',
        //     'menu_id'=>$goodsReceipt,
        //     'created_at' => date('Y-m-d'),
        //     'updated_at' => date('Y-m-d')
        // ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'View GR',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'goods_receipt.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$goodsReceipt,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Material Requisition',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        $materialRequisition =  Menu::where('name','Material Requisition')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Create MR Manually',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'material_requisition.create',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialRequisition,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Approve MR',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'material_requisition.indexApprove',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialRequisition,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'View MR',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'material_requisition.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialRequisition,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Goods Issue',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        $goodsIssue =  Menu::where('name','Goods Issue')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Create GI with Reference',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'goods_issue.createGiWithRef',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$goodsIssue,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Create GI without Reference',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'goods_issue.createGiWithoutRef',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$goodsIssue,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'View GI',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'goods_issue.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$goodsIssue,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


         DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Physical Inventory',
            'icon' => 'fa-file-text-o',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        $physicalInventory =  Menu::where('name','Physical Inventory')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Snapshot',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'physical_inventory.indexSnapshot',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$physicalInventory,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Count Stock',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'physical_inventory.indexCountStock',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$physicalInventory,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 3,
            'name' => 'Adjust Stock',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'physical_inventory.indexAdjustStock',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$physicalInventory,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Stock Management',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'stock_management.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Material Write Off',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'material_write_off.create',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Goods Movement',
            'icon' => 'fa-file-text-o',
            'route_name'=> 'goods_movement.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$materialManagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Resource Management',
            'icon' => 'fa-database',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);
        
        $resourcemanagement = Menu::where('name','Resource Management')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Manage Resource',
            'icon' => 'fa-wrench',
            'route_name'=> 'resource.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=> $resourcemanagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Assign Resource',
            'icon' => 'fa-wrench',
            'route_name'=> 'resource.assignResource',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=> $resourcemanagement,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Production Planning & Execution',
            'icon' => 'fa-database',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        $PPE =  Menu::where('name','Production Planning & Execution')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Create Production Order',
            'icon' => 'fa-wrench',
            'route_name'=> 'production_order.selectProject',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$PPE,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Release Production Order',
            'icon' => 'fa-wrench',
            'route_name'=> 'production_order.selectProjectRelease',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$PPE,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Confirm Production Order',
            'icon' => 'fa-wrench',
            'route_name'=> 'production_order.selectProjectConfirm',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$PPE,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Production Order Actual Cost Report',
            'icon' => 'fa-wrench',
            'route_name'=> 'production_order.selectProjectReport',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$PPE,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Yard Plan',
            'icon' => 'fa-wrench',
            'route_name'=> 'yard_plan.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$PPE,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Master Data',
            'icon' => 'fa-database',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        $masterData =  Menu::where('name','Master Data')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Ship',
            'icon' => 'fa-wrench',
            'route_name'=> 'ship.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);
        

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Branch',
            'icon' => 'fa-wrench',
            'route_name'=> 'branch.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Company',
            'icon' => 'fa-wrench',
            'route_name'=> 'company.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Storage Location',
            'icon' => 'fa-wrench',
            'route_name'=> 'storage_location.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Customer',
            'icon' => 'fa-wrench',
            'route_name'=> 'customer.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Material',
            'icon' => 'fa-wrench',
            'route_name'=> 'material.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id' => $masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d'),
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Unit Of Measurement',
            'icon' => 'fa-wrench',
            'route_name'=> 'unit_of_measurement.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id' => $masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d'),
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Vendor',
            'icon' => 'fa-wrench',
            'route_name'=> 'vendor.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id' => $masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d'),
        ]);


        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Warehouse',
            'icon' => 'fa-wrench',
            'route_name'=> 'warehouse.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id' => $masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d'),
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Yard',
            'icon' => 'fa-wrench',
            'route_name'=> 'yard.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id' => $masterData,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d'),
        ]);


        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Configuration',
            'icon' => 'fa-database',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        $configuration =  Menu::where('name','Configuration')->select('id')->first()->id;
        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Menus',
            'icon' => 'fa-wrench',
            'route_name'=> 'menus.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$configuration,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Appearance',
            'icon' => 'fa-wrench',
            'route_name'=> 'appearance.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$configuration,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 2,
            'name' => 'Currencies',
            'icon' => 'fa-wrench',
            'route_name'=> 'currencies.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'menu_id'=>$configuration,
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'User Management',
            'icon' => 'fa-users',
            'route_name'=> 'user.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Role Management',
            'icon' => 'fa-user-secret',
            'route_name'=> 'role.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d')
        ]);

        DB::table('menus')->insert([
            'level' => 1,
            'name' => 'Permission Management',
            'icon' => 'fa-ban',
            'route_name'=> 'permission.index',
            'is_active' => true,
            'roles' => 'ADMIN',
            'created_at' => date('Y-m-d'),
            'updated_at' => date('Y-m-d'),
        ]);
    }
}

